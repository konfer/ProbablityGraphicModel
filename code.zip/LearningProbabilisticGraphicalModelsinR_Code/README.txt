Appendix doesn't have any code.

All the examples in this book can be used with R version 3 or above on any platform and operating system supporting R.

This book is for anyone who has to deal with lots of data and draw conclusions from it, especially when the data is noisy or uncertain. Data scientists, machine learning enthusiasts, engineers, and those who are curious about the latest advances in machine learning will find PGM interesting.